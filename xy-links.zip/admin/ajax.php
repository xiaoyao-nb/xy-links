<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
check_login();

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'regen_sitemap':
        try {
            $xml = generate_sitemap();
            file_put_contents(__DIR__ . '/../sitemap.xml', $xml);
            echo json_encode(['success' => true, 'message' => 'Sitemap 已生成']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;
        
    case 'get_theme_vars':
        $key = $_GET['key'] ?? '';
        $db = Database::getInstance();
        $theme = $db->fetch("SELECT css_vars FROM themes WHERE theme_key=?", [$key]);
        if ($theme) {
            echo json_encode(['success' => true, 'vars' => json_decode($theme['css_vars'], true)]);
        } else {
            echo json_encode(['success' => false]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => '未知操作']);
}
