<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
check_login();

$db = Database::getInstance();
$page = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - 导航管理</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            min-height: 100vh;
            background: #0d0d18;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
            color: #e0e0e0;
            display: flex;
        }

        /* 侧边栏 */
        .sidebar {
            width: 240px;
            background: rgba(255,255,255,0.03);
            border-right: 1px solid rgba(255,255,255,0.08);
            padding: 24px 0;
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform .3s ease;
        }
        .sidebar-header { padding: 0 24px 24px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 16px; }
        .sidebar-header h1 { font-size: 1.2rem; color: #fff; }
        .sidebar-header span { font-size: .78rem; color: #888; }

        .nav-item {
            display: flex; align-items: center; gap: 10px;
            padding: 12px 24px; color: #a0a0a0;
            text-decoration: none; transition: all .2s;
            border-left: 3px solid transparent; font-size: .92rem;
        }
        .nav-item:hover { background: rgba(99,102,241,.1); color: #fff; }
        .nav-item.active { background: rgba(99,102,241,.15); color: #6366f1; border-left-color: #6366f1; }
        .nav-item .icon { font-size: 1.2rem; width: 24px; text-align: center; }

        /* 主内容区 */
        .main-area { margin-left: 240px; flex: 1; padding: 0; }
        .top-bar {
            height: 60px; background: rgba(255,255,255,0.02);
            border-bottom: 1px solid rgba(255,255,255,0.08);
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 28px; position: sticky; top: 0; z-index: 100;
        }
        .top-bar h2 { font-size: 1.1rem; font-weight: 600; }
        .top-bar-right { display: flex; align-items: center; gap: 16px; }
        .btn-top {
            padding: 6px 14px; background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1); border-radius: 8px;
            color: #a0a0a0; text-decoration: none; font-size: .85rem; transition: all .2s;
        }
        .btn-top:hover { background: rgba(99,102,241,.2); color: #fff; }
        .content-area { padding: 28px; }

        /* 卡片/表单/按钮/表格/统计/主题/消息/开关 —— 与你原文件完全一致，省略以保持稳定 */
        .card { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 24px; margin-bottom: 20px; }
        .card h3 { font-size: 1rem; margin-bottom: 16px; color: #fff; }
        .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px,1fr)); gap: 14px; margin-bottom: 14px; }
        .form-group label { display: block; margin-bottom: 5px; color: #999; font-size: .82rem; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 9px 14px; background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1); border-radius: 8px;
            color: #e0e0e0; font-size: .9rem; outline: none; transition: border .2s;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus { border-color: #6366f1; }
        .form-group textarea { resize: vertical; min-height: 70px; }
        .btn { padding: 9px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: .88rem; font-weight: 500; transition: all .2s; }
        .btn-primary { background: #6366f1; color: #fff; }
        .btn-primary:hover { filter: brightness(1.1); }
        .btn-danger { background: rgba(239,68,68,.15); color: #fca5a5; border: 1px solid rgba(239,68,68,.3); }
        .btn-danger:hover { background: rgba(239,68,68,.25); }
        .btn-sm { padding: 5px 12px; font-size: .8rem; }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th { text-align: left; padding: 10px 14px; color: #888; font-size: .78rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid rgba(255,255,255,0.08); }
        .data-table td { padding: 12px 14px; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: .88rem; }
        .data-table tr:hover td { background: rgba(255,255,255,0.02); }
        .table-actions { display: flex; gap: 6px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px,1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 20px; text-align: center; }
        .stat-card .num { font-size: 2rem; font-weight: 700; color: #6366f1; }
        .stat-card .label { font-size: .82rem; color: #888; margin-top: 4px; }
        .theme-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px,1fr)); gap: 14px; }
        .theme-card { background: rgba(255,255,255,0.03); border: 2px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 16px; cursor: pointer; transition: all .2s; position: relative; }
        .theme-card:hover { border-color: rgba(99,102,241,.4); }
        .theme-card.active { border-color: #6366f1; }
        .theme-preview { height: 60px; border-radius: 8px; margin-bottom: 10px; }
        .theme-card .name { font-size: .9rem; font-weight: 600; }
        .theme-card .tag { font-size: .72rem; color: #888; }
        .theme-card .check { position: absolute; top: 10px; right: 10px; color: #6366f1; font-size: 1.1rem; display: none; }
        .theme-card.active .check { display: block; }
        .alert { padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; font-size: .88rem; }
        .alert-success { background: rgba(34,197,94,.12); border: 1px solid rgba(34,197,94,.3); color: #86efac; }
        .alert-error { background: rgba(239,68,68,.12); border: 1px solid rgba(239,68,68,.3); color: #fca5a5; }
        .switch { position: relative; display: inline-block; width: 44px; height: 24px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; inset: 0; background: rgba(255,255,255,0.1); border-radius: 24px; transition: .3s; }
        .slider:before { content:""; position: absolute; height: 18px; width: 18px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: .3s; }
        .switch input:checked + .slider { background: #6366f1; }
        .switch input:checked + .slider:before { transform: translateX(20px); }

        /* ===== 移动端汉堡菜单（≤768px） ===== */
        .menu-toggle {
            display: none; position: fixed; top: 12px; left: 12px; z-index: 1001;
            width: 42px; height: 42px; border-radius: 8px;
            background: rgba(99,102,241,.25); border: 1px solid rgba(255,255,255,.2);
            color: #fff; font-size: 22px; line-height: 42px; text-align: center;
            cursor: pointer; backdrop-filter: blur(6px);
        }
        .drawer-mask { display: none; position: fixed; inset: 0; z-index: 998; background: rgba(0,0,0,.5); }

        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.open { transform: translateX(0); }
            .drawer-mask.show { display: block; }
            .main-area { margin-left: 0; }
            .top-bar { padding-left: 60px; }   /* 给汉堡按钮留位 */
            .content-area { padding: 16px 12px; }
            table { display: block; overflow-x: auto; white-space: nowrap; }
            .card { padding: 18px; }
        }
    </style>
</head>
<body>

<!-- 汉堡按钮 + 遮罩 -->
<button class="menu-toggle" id="menuToggle" onclick="toggleMenu()">☰</button>
<div class="drawer-mask" id="drawerMask" onclick="toggleMenu()"></div>

<!-- 侧边栏 -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h1>⚙️ 管理后台</h1>
        <span>导航站点管理系统</span>
    </div>
    <a href="?page=dashboard" class="nav-item <?php echo $page=='dashboard'?'active':''; ?>">
        <span class="icon">📊</span> 仪表盘
    </a>
    <a href="?page=links" class="nav-item <?php echo $page=='links'?'active':''; ?>">
        <span class="icon">🔗</span> 导航管理
    </a>
    <a href="?page=seo" class="nav-item <?php echo $page=='seo'?'active':''; ?>">
        <span class="icon">🔍</span> SEO设置
    </a>
    <a href="?page=themes" class="nav-item <?php echo $page=='themes'?'active':''; ?>">
        <span class="icon">🎨</span> 主题管理
    </a>
    <a href="?page=settings" class="nav-item <?php echo $page=='settings'?'active':''; ?>">
        <span class="icon">⚙️</span> 站点设置
    </a>
    <a href="?page=password" class="nav-item <?php echo $page=='password'?'active':''; ?>">
        <span class="icon">🔑</span> 修改密码
    </a>
</aside>

<!-- 主区域 -->
<div class="main-area">
    <div class="top-bar">
        <h2>
            <?php
            $titles = [
                'dashboard'=>'仪表盘','links'=>'导航管理','seo'=>'SEO设置',
                'themes'=>'主题管理','settings'=>'站点设置','password'=>'修改密码'
            ];
            echo $titles[$page] ?? '管理后台';
            ?>
        </h2>
        <div class="top-bar-right">
            <a href="../" class="btn-top" target="_blank">🌐 查看首页</a>
            <a href="logout.php" class="btn-top">退出登录</a>
        </div>
    </div>

    <div class="content-area">
        <?php
        switch ($page) {
            case 'dashboard': include __DIR__.'/pages/dashboard.php'; break;
            case 'links':     include __DIR__.'/pages/links.php';     break;
            case 'seo':      include __DIR__.'/pages/seo.php';      break;
            case 'themes':   include __DIR__.'/pages/themes.php';   break;
            case 'settings': include __DIR__.'/pages/settings.php'; break;
            case 'password': include __DIR__.'/pages/password.php'; break;
            default:          include __DIR__.'/pages/dashboard.php';
        }
        ?>
    </div>
</div>

<script>
function toggleMenu(){
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('drawerMask').classList.toggle('show');
}
/* 点菜单项后自动关抽屉 */
document.querySelectorAll('.sidebar a').forEach(a=>{
    a.addEventListener('click', ()=>{
        if(window.innerWidth<=768) toggleMenu();
    });
});
</script>
</body>
</html>
