<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

session_start();

// 已登录直接跳转
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $db = Database::getInstance();
    $admin = $db->fetch("SELECT * FROM admins WHERE username = ?", [$username]);
    
    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $admin['id'];
        header('Location: index.php');
        exit;
    } else {
        $error = '用户名或密码错误';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台登录 - 导航管理</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
            color: #e8e8e8;
        }
        .login-box {
            background: rgba(255,255,255,0.06);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 20px;
            padding: 48px 40px;
            width: 380px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }
        .login-box h1 {
            text-align: center;
            font-size: 1.6rem;
            margin-bottom: 8px;
            background: linear-gradient(135deg, #e8e8e8, #6366f1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .login-box p {
            text-align: center;
            color: #a0a0b0;
            font-size: 0.85rem;
            margin-bottom: 32px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            color: #a0a0b0;
            font-size: 0.85rem;
        }
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            color: #e8e8e8;
            font-size: 1rem;
            outline: none;
            transition: all 0.3s;
        }
        .form-group input:focus {
            border-color: #6366f1;
            box-shadow: 0 0 15px rgba(99,102,241,0.3);
        }
        .btn-login {
            width: 100%;
            padding: 13px;
            background: #6366f1;
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 8px;
        }
        .btn-login:hover {
            filter: brightness(1.1);
            box-shadow: 0 0 20px rgba(99,102,241,0.4);
        }
        .error-msg {
            background: rgba(239,68,68,0.15);
            border: 1px solid rgba(239,68,68,0.3);
            color: #fca5a5;
            padding: 10px 14px;
            border-radius: 10px;
            font-size: 0.85rem;
            margin-bottom: 20px;
            text-align: center;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #a0a0b0;
            text-decoration: none;
            font-size: 0.85rem;
        }
        .back-link:hover { color: #6366f1; }
    </style>
</head>
<body>
    <div class="login-box">
        <h1>🔐 管理后台</h1>
        <p>导航站点管理系统</p>
        
        <?php if ($error): ?>
        <div class="error-msg"><?php echo h($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" placeholder="请输入用户名" required value="<?php echo h($_POST['username'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" placeholder="请输入密码" required>
            </div>
            <button type="submit" class="btn-login">登 录</button>
        </form>
        
        <a href="../" class="back-link">← 返回导航首页</a>
    </div>
</body>
</html>
