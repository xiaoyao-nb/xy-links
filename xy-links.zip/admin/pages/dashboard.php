<?php
$db = Database::getInstance();
$link_count = $db->fetch("SELECT COUNT(*) as c FROM nav_links")['c'];
$cat_count = $db->fetch("SELECT COUNT(*) as c FROM nav_categories")['c'];
$theme_count = $db->fetch("SELECT COUNT(*) as c FROM themes")['c'];
$seo = get_seo_config();
$site = get_site_config();
?>
<div class="stats-grid">
    <div class="stat-card">
        <div class="num"><?php echo $link_count; ?></div>
        <div class="label">导航链接</div>
    </div>
    <div class="stat-card">
        <div class="num"><?php echo $cat_count; ?></div>
        <div class="label">分类数量</div>
    </div>
    <div class="stat-card">
        <div class="num"><?php echo $theme_count; ?></div>
        <div class="label">可用主题</div>
    </div>
    <div class="stat-card">
        <div class="num"><?php echo ($seo['allow_robots'] ?? 0) ? '✅' : '⛔'; ?></div>
        <div class="label">搜索引擎收录</div>
    </div>
</div>

<div class="card">
    <h3>📋 系统信息</h3>
    <table class="data-table">
        <tr><td style="width:160px;color:#888">站点标题</td><td><?php echo h($seo['site_title'] ?? ''); ?></td></tr>
        <tr><td style="color:#888">当前主题</td><td><?php echo h($site['current_theme'] ?? ''); ?></td></tr>
        <tr><td style="color:#888">备案号</td><td><?php echo h($site['beian_number'] ?: '未设置'); ?></td></tr>
        <tr><td style="color:#888">版权信息</td><td><?php echo h($site['copyright_text'] ?? ''); ?></td></tr>
        <tr><td style="color:#888">外站跳转提示</td><td><?php echo ($site['external_warning'] ?? 1) ? '已开启' : '已关闭'; ?></td></tr>
        <tr><td style="color:#888">PHP版本</td><td><?php echo PHP_VERSION; ?></td></tr>
        <tr><td style="color:#888">服务器</td><td><?php echo h($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'); ?></td></tr>
    </table>
</div>

<div class="card">
    <h3>🚀 快速操作</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
        <a href="?page=links&action=add" class="btn btn-primary">+ 添加导航链接</a>
        <a href="?page=seo" class="btn btn-primary" style="background:rgba(99,102,241,0.2);color:#a5b4fc">SEO设置</a>
        <a href="?page=themes" class="btn btn-primary" style="background:rgba(99,102,241,0.2);color:#a5b4fc">更换主题</a>
        <a href="?page=settings" class="btn btn-primary" style="background:rgba(99,102,241,0.2);color:#a5b4fc">站点设置</a>
    </div>
</div>
