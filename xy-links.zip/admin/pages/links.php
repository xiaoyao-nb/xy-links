<?php
$db = Database::getInstance();
$action = $_GET['action'] ?? 'list';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $url = trim($_POST['url'] ?? '');
    $icon = trim($_POST['icon'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '其他');
    $sort_order = intval($_POST['sort_order'] ?? 0);
    $is_external = isset($_POST['is_external']) ? 1 : 1;
    $status = isset($_POST['status']) ? 1 : 1;
    
    if (empty($title) || empty($url)) {
        $msg = ['type' => 'error', 'text' => '网站名称和地址不能为空'];
    } else {
        if ($action === 'edit' && !empty($_POST['id'])) {
            $db->execute(
                "UPDATE nav_links SET title=?, url=?, icon=?, description=?, category=?, sort_order=?, is_external=?, status=? WHERE id=?",
                [$title, $url, $icon, $description, $category, $sort_order, $is_external, $status, $_POST['id']]
            );
            $msg = ['type' => 'success', 'text' => '更新成功！'];
        } else {
            $db->execute(
                "INSERT INTO nav_links (title, url, icon, description, category, sort_order, is_external, status) VALUES (?,?,?,?,?,?,?,?)",
                [$title, $url, $icon, $description, $category, $sort_order, $is_external, $status]
            );
            $msg = ['type' => 'success', 'text' => '添加成功！'];
        }
        // 同步分类
        $exists = $db->fetch("SELECT id FROM nav_categories WHERE name=?", [$category]);
        if (!$exists && !empty($category)) {
            $db->execute("INSERT INTO nav_categories (name) VALUES (?)", [$category]);
        }
    }
    
    if ($action === 'edit') $action = 'list';
}

// 删除
if ($action === 'delete' && !empty($_GET['id'])) {
    $db->execute("DELETE FROM nav_links WHERE id=?", [$_GET['id']]);
    $msg = ['type' => 'success', 'text' => '删除成功！'];
    $action = 'list';
}

// 获取编辑数据
$edit_data = null;
if ($action === 'edit' && !empty($_GET['id'])) {
    $edit_data = $db->fetch("SELECT * FROM nav_links WHERE id=?", [$_GET['id']]);
}

// 获取分类列表
$categories = $db->fetchAll("SELECT * FROM nav_categories ORDER BY sort_order ASC");

// 获取链接列表
$links = $db->fetchAll("SELECT * FROM nav_links ORDER BY sort_order ASC, id DESC");
?>

<?php if (isset($msg)): ?>
<div class="alert alert-<?php echo $msg['type']==='success'?'success':'error'; ?>">
    <?php echo h($msg['text']); ?>
</div>
<?php endif; ?>

<?php if ($action === 'add' || $action === 'edit'): ?>
<!-- 添加/编辑表单 -->
<div class="card">
    <h3><?php echo $action==='edit'?'✏️ 编辑导航':'➕ 添加导航'; ?></h3>
    <form method="POST" action="?page=links&action=<?php echo $action; ?>">
        <?php if ($edit_data): ?>
        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
        <?php endif; ?>
        
        <div class="form-row">
            <div class="form-group">
                <label>网站名称 *</label>
                <input type="text" name="title" required value="<?php echo h($edit_data['title'] ?? ''); ?>" placeholder="如：百度">
            </div>
            <div class="form-group">
                <label>网站地址 *</label>
                <input type="url" name="url" required value="<?php echo h($edit_data['url'] ?? ''); ?>" placeholder="https://www.example.com">
            </div>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>图标/封面 URL</label>
                <input type="url" name="icon" value="<?php echo h($edit_data['icon'] ?? ''); ?>" placeholder="https://example.com/icon.png 或 favicon.ico">
                <small style="color:#666;font-size:0.75rem">留空则自动使用首字母</small>
            </div>
            <div class="form-group">
                <label>分类</label>
                <input type="text" name="category" list="catList" value="<?php echo h($edit_data['category'] ?? '常用'); ?>" placeholder="如：开发工具">
                <datalist id="catList">
                    <?php foreach ($categories as $c): ?>
                    <option value="<?php echo h($c['name']); ?>">
                    <?php endforeach; ?>
                </datalist>
            </div>
        </div>
        
        <div class="form-group" style="margin-bottom:14px">
            <label>描述</label>
            <textarea name="description" placeholder="一句话描述这个网站"><?php echo h($edit_data['description'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>排序权重（数字越小越靠前）</label>
                <input type="number" name="sort_order" value="<?php echo h($edit_data['sort_order'] ?? 0); ?>">
            </div>
            <div class="form-group">
                <label>状态</label>
                <select name="status">
                    <option value="1" <?php echo ($edit_data['status'] ?? 1)==1?'selected':''; ?>>启用</option>
                    <option value="0" <?php echo ($edit_data['status'] ?? 1)==0?'selected':''; ?>>禁用</option>
                </select>
            </div>
        </div>
        
        <div style="display:flex;gap:10px;margin-top:8px">
            <button type="submit" class="btn btn-primary">💾 保存</button>
            <a href="?page=links" class="btn btn-danger" style="line-height:1.5;text-decoration:none">取消</a>
        </div>
    </form>
</div>

<?php else: ?>
<!-- 链接列表 -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
    <h3 style="color:#fff;font-size:1rem">导航链接列表</h3>
    <a href="?page=links&action=add" class="btn btn-primary">➕ 添加链接</a>
</div>

<div class="card" style="padding:0;overflow:hidden">
    <table class="data-table">
        <thead>
            <tr>
                <th style="width:50px">ID</th>
                <th style="width:60px">图标</th>
                <th>名称</th>
                <th>分类</th>
                <th>地址</th>
                <th style="width:60px">排序</th>
                <th style="width:60px">状态</th>
                <th style="width:120px">操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($links as $link): ?>
            <tr>
                <td><?php echo $link['id']; ?></td>
                <td>
                    <?php if (!empty($link['icon'])): ?>
                    <img src="<?php echo h($link['icon']); ?>" style="width:28px;height:28px;border-radius:6px;object-fit:cover" 
                         onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2228%22 height=%2228%22><rect width=%2228%22 height=%2228%22 rx=%226%22 fill=%22%236366f1%22/><text x=%2214%22 y=%2218%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2212%22 font-family=%22sans-serif%22><?php echo mb_substr(h($link['title']),0,1); ?></text></svg>'">
                    <?php else: ?>
                    <div style="width:28px;height:28px;border-radius:6px;background:#6366f1;display:flex;align-items:center;justify-content:center;font-size:0.7rem;color:#fff">
                        <?php echo mb_substr(h($link['title']),0,1); ?>
                    </div>
                    <?php endif; ?>
                </td>
                <td><strong><?php echo h($link['title']); ?></strong><br><small style="color:#666"><?php echo h($link['description'] ?? ''); ?></small></td>
                <td><span style="background:rgba(99,102,241,0.15);padding:2px 8px;border-radius:4px;font-size:0.78rem"><?php echo h($link['category']); ?></span></td>
                <td><small style="color:#888"><?php echo h(mb_substr($link['url'],0,40)); ?><?php echo mb_strlen($link['url'])>40?'...':''; ?></small></td>
                <td><?php echo $link['sort_order']; ?></td>
                <td>
                    <?php if ($link['status']): ?>
                    <span style="color:#86efac;font-size:0.8rem">● 启用</span>
                    <?php else: ?>
                    <span style="color:#fca5a5;font-size:0.8rem">● 禁用</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="table-actions">
                        <a href="?page=links&action=edit&id=<?php echo $link['id']; ?>" class="btn btn-sm btn-primary" style="background:rgba(99,102,241,0.2);color:#a5b4fc">编辑</a>
                        <a href="?page=links&action=delete&id=<?php echo $link['id']; ?>" class="btn btn-sm btn-danger" 
                           onclick="return confirm('确定删除「<?php echo h($link['title']); ?>」吗？')">删除</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($links)): ?>
            <tr><td colspan="8" style="text-align:center;padding:40px;color:#666">暂无导航链接，<a href="?page=links&action=add" style="color:#6366f1">立即添加</a></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
