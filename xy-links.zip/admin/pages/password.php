<?php
$db = Database::getInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_pwd = $_POST['old_password'] ?? '';
    $new_pwd = $_POST['new_password'] ?? '';
    $confirm_pwd = $_POST['confirm_password'] ?? '';
    
    $admin = $db->fetch("SELECT * FROM admins WHERE id=?", [$_SESSION['admin_id']]);
    
    if (!password_verify($old_pwd, $admin['password'])) {
        $msg = ['type' => 'error', 'text' => '原密码错误'];
    } elseif (strlen($new_pwd) < 6) {
        $msg = ['type' => 'error', 'text' => '新密码至少6位'];
    } elseif ($new_pwd !== $confirm_pwd) {
        $msg = ['type' => 'error', 'text' => '两次密码不一致'];
    } else {
        $hash = password_hash($new_pwd, PASSWORD_DEFAULT);
        $db->execute("UPDATE admins SET password=? WHERE id=?", [$hash, $_SESSION['admin_id']]);
        $msg = ['type' => 'success', 'text' => '密码修改成功！'];
    }
}
?>

<?php if (isset($msg)): ?>
<div class="alert alert-<?php echo $msg['type']==='success'?'success':'error'; ?>">
    <?php echo h($msg['text']); ?>
</div>
<?php endif; ?>

<div class="card" style="max-width:500px">
    <h3>🔑 修改管理员密码</h3>
    <p style="color:#888;font-size:0.82rem;margin-bottom:20px">默认账号：admin / admin123，请尽快修改</p>
    
    <form method="POST" action="?page=password">
        <div class="form-group" style="margin-bottom:14px">
            <label>原密码</label>
            <input type="password" name="old_password" required placeholder="输入当前密码">
        </div>
        <div class="form-group" style="margin-bottom:14px">
            <label>新密码</label>
            <input type="password" name="new_password" required placeholder="至少6位">
        </div>
        <div class="form-group" style="margin-bottom:20px">
            <label>确认新密码</label>
            <input type="password" name="confirm_password" required placeholder="再次输入新密码">
        </div>
        <button type="submit" class="btn btn-primary">🔒 更新密码</button>
    </form>
</div>
