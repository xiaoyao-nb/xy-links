<?php
$db = Database::getInstance();
$seo = $db->fetch("SELECT * FROM seo_config ORDER BY id DESC LIMIT 1") ?: [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_title = trim($_POST['site_title'] ?? '');
    $site_description = trim($_POST['site_description'] ?? '');
    $site_keywords = trim($_POST['site_keywords'] ?? '');
    $allow_robots = isset($_POST['allow_robots']) ? 1 : 0;
    $robots_txt = trim($_POST['robots_txt'] ?? '');
    $sitemap_enabled = isset($_POST['sitemap_enabled']) ? 1 : 0;
    
    if (empty($seo['id'])) {
        $db->execute(
            "INSERT INTO seo_config (site_title, site_description, site_keywords, allow_robots, robots_txt, sitemap_enabled) VALUES (?,?,?,?,?,?)",
            [$site_title, $site_description, $site_keywords, $allow_robots, $robots_txt, $sitemap_enabled]
        );
    } else {
        $db->execute(
            "UPDATE seo_config SET site_title=?, site_description=?, site_keywords=?, allow_robots=?, robots_txt=?, sitemap_enabled=? WHERE id=?",
            [$site_title, $site_description, $site_keywords, $allow_robots, $robots_txt, $sitemap_enabled, $seo['id']]
        );
    }
    
    // 更新sitemap
    if ($sitemap_enabled) {
        $sitemap = generate_sitemap();
        file_put_contents(__DIR__ . '/../../sitemap.xml', $sitemap);
    }
    
    $msg = ['type' => 'success', 'text' => 'SEO设置已保存！'];
    $seo = $db->fetch("SELECT * FROM seo_config ORDER BY id DESC LIMIT 1");
}
?>

<?php if (isset($msg)): ?>
<div class="alert alert-<?php echo $msg['type']==='success'?'success':'error'; ?>">
    <?php echo h($msg['text']); ?>
</div>
<?php endif; ?>

<div class="card">
    <h3>🔍 SEO 基础设置</h3>
    <p style="color:#888;font-size:0.82rem;margin-bottom:20px">这些设置直接影响搜索引擎对你网站的理解和收录</p>
    
    <form method="POST" action="?page=seo">
        <div class="form-group" style="margin-bottom:14px">
            <label>站点标题（Title）*</label>
            <input type="text" name="site_title" required value="<?php echo h($seo['site_title'] ?? ''); ?>" placeholder="如：我的个人导航 - 精选优质网站">
            <small style="color:#666;font-size:0.75rem">建议不超过60个字符，包含核心关键词</small>
        </div>
        
        <div class="form-group" style="margin-bottom:14px">
            <label>站点描述（Description）</label>
            <textarea name="site_description" placeholder="一句话描述你的导航站是做什么的"><?php echo h($seo['site_description'] ?? ''); ?></textarea>
            <small style="color:#666;font-size:0.75rem">建议120-160个字符，概括站点核心内容</small>
        </div>
        
        <div class="form-group" style="margin-bottom:14px">
            <label>关键词（Keywords）</label>
            <input type="text" name="site_keywords" value="<?php echo h($seo['site_keywords'] ?? ''); ?>" placeholder="导航,个人主页,网址导航（逗号分隔）">
            <small style="color:#666;font-size:0.75rem">用中文逗号或英文逗号分隔，3-8个为佳</small>
        </div>
        
        <div style="display:flex;gap:24px;margin-bottom:20px;flex-wrap:wrap">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <label class="switch">
                    <input type="checkbox" name="allow_robots" <?php echo ($seo['allow_robots'] ?? 1) ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
                <span style="font-size:0.88rem">允许搜索引擎爬取（强烈建议开启）</span>
            </label>
            
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <label class="switch">
                    <input type="checkbox" name="sitemap_enabled" <?php echo ($seo['sitemap_enabled'] ?? 1) ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
                <span style="font-size:0.88rem">启用 Sitemap.xml</span>
            </label>
        </div>
        
        <div class="form-group" style="margin-bottom:20px">
            <label>robots.txt 内容</label>
            <textarea name="robots_txt" placeholder="User-agent: *&#10;Allow: /"><?php echo h($seo['robots_txt'] ?? "User-agent: *\nAllow: /\n\nSitemap: sitemap.xml"); ?></textarea>
            <small style="color:#666;font-size:0.75rem">控制爬虫行为的规则文件内容</small>
        </div>
        
        <button type="submit" class="btn btn-primary">💾 保存SEO设置</button>
    </form>
</div>

<div class="card">
    <h3>📄 SEO 工具</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <a href="../sitemap.xml" target="_blank" class="btn btn-primary" style="background:rgba(99,102,241,0.2);color:#a5b4fc">查看 Sitemap</a>
        <a href="../robots.txt" target="_blank" class="btn btn-primary" style="background:rgba(99,102,241,0.2);color:#a5b4fc">查看 Robots.txt</a>
        <button onclick="regenerateSitemap()" class="btn btn-primary" style="background:rgba(34,197,94,0.2);color:#86efac">🔄 重新生成Sitemap</button>
    </div>
</div>

<script>
function regenerateSitemap() {
    fetch('ajax.php?action=regen_sitemap')
        .then(r => r.json())
        .then(data => {
            alert(data.success ? 'Sitemap 生成成功！' : '生成失败：' + data.message);
        });
}
</script>
