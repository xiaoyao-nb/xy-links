<?php
$db = Database::getInstance();
$site = $db->fetch("SELECT * FROM site_config ORDER BY id DESC LIMIT 1") ?: [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $beian_number        = trim($_POST['beian_number'] ?? '');
    $beian_link          = trim($_POST['beian_link'] ?? '');
    $copyright_text      = trim($_POST['copyright_text'] ?? '');
    $footer_extra        = trim($_POST['footer_extra'] ?? '');
    $external_warning    = isset($_POST['external_warning']) ? 1 : 0;
    $external_warning_text = trim($_POST['external_warning_text'] ?? '您即将离开本站，跳转到第三方网站，请注意安全');
    // v2.0 新增
    $avatar_url          = trim($_POST['avatar_url'] ?? '');
    $bg_image            = trim($_POST['bg_image'] ?? '');
    $sub_title           = trim($_POST['sub_title'] ?? '');

    if (empty($site['id'])) {
        $db->execute(
            "INSERT INTO site_config (beian_number,beian_link,copyright_text,footer_extra,external_warning,external_warning_text,avatar_url,bg_image,sub_title) VALUES (?,?,?,?,?,?,?,?,?)",
            [$beian_number,$beian_link,$copyright_text,$footer_extra,$external_warning,$external_warning_text,$avatar_url,$bg_image,$sub_title]
        );
    } else {
        $db->execute(
            "UPDATE site_config SET beian_number=?,beian_link=?,copyright_text=?,footer_extra=?,external_warning=?,external_warning_text=?,avatar_url=?,bg_image=?,sub_title=? WHERE id=?",
            [$beian_number,$beian_link,$copyright_text,$footer_extra,$external_warning,$external_warning_text,$avatar_url,$bg_image,$sub_title,$site['id']]
        );
    }

    $msg = ['type' => 'success', 'text' => '站点设置已保存！'];
    $site = $db->fetch("SELECT * FROM site_config ORDER BY id DESC LIMIT 1");
}
?>
<?php if (isset($msg)): ?>
<div class="alert alert-<?php echo $msg['type']==='success'?'success':'error'; ?>">
    <?php echo h($msg['text']); ?>
</div>
<?php endif; ?>

<div class="card">
    <h3>🎨 外观设置</h3>
    <p style="color:#888;font-size:0.82rem;margin-bottom:18px">配置首页头像、背景图和副标题，打造专属导航页</p>

    <form method="POST" action="?page=settings">
        <div class="form-row">
            <div class="form-group">
                <label>头像图片URL</label>
                <input type="url" name="avatar_url" value="<?php echo h($site['avatar_url'] ?? ''); ?>" placeholder="https://example.com/avatar.jpg">
                <small style="color:#666;font-size:0.75rem">留空则显示站点名称首字母方块</small>
            </div>
            <div class="form-group">
                <label>背景图片URL</label>
                <input type="url" name="bg_image" value="<?php echo h($site['bg_image'] ?? ''); ?>" placeholder="https://example.com/bg.jpg">
                <small style="color:#666;font-size:0.75rem">留空则使用主题渐变背景</small>
            </div>
        </div>

        <div class="form-group" style="margin-bottom:20px">
            <label>副标题 / 描述语</label>
            <input type="text" name="sub_title" value="<?php echo h($site['sub_title'] ?? '简洁 · 实用 · 高效工具导航'); ?>" placeholder="如：简洁 · 实用 · 高效工具导航">
        </div>

        <hr style="border:0;border-top:1px solid rgba(255,255,255,0.08);margin:20px 0">

        <h4 style="color:#aaa;margin-bottom:14px;font-size:0.9rem">📋 备案与版权</h4>

        <div class="form-row">
            <div class="form-group">
                <label>备案号</label>
                <input type="text" name="beian_number" value="<?php echo h($site['beian_number'] ?? ''); ?>" placeholder="如：京ICP备xxxxxxxx号">
                <small style="color:#666;font-size:0.75rem">留空则不显示备案信息</small>
            </div>
            <div class="form-group">
                <label>备案查询链接</label>
                <input type="url" name="beian_link" value="<?php echo h($site['beian_link'] ?? ''); ?>" placeholder="https://beian.miit.gov.cn">
            </div>
        </div>

        <div class="form-group" style="margin-bottom:14px">
            <label>版权信息</label>
            <input type="text" name="copyright_text" value="<?php echo h($site['copyright_text'] ?? '© 2026 我的导航页. All Rights Reserved.'); ?>" placeholder="© 2026 Your Name. All Rights Reserved.">
        </div>

        <div class="form-group" style="margin-bottom:20px">
            <label>底部额外信息</label>
            <textarea name="footer_extra" placeholder="可放统计代码、联系方式等"><?php echo h($site['footer_extra'] ?? ''); ?></textarea>
            <small style="color:#666;font-size:0.75rem">支持HTML，如百度统计、Google Analytics代码等</small>
        </div>

        <hr style="border:0;border-top:1px solid rgba(255,255,255,0.08);margin:20px 0">

        <h4 style="color:#aaa;margin-bottom:14px;font-size:0.9rem">🛡️ 外站跳转安全提示</h4>

        <div style="margin-bottom:16px">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <label class="switch">
                    <input type="checkbox" name="external_warning" <?php echo ($site['external_warning'] ?? 1) ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
                <span style="font-size:0.88rem">开启外站跳转确认弹窗</span>
            </label>
            <small style="color:#666;font-size:0.75rem;display:block;margin-top:4px">关闭后点击外站链接将直接跳转，无确认提示</small>
        </div>

        <div class="form-group" style="margin-bottom:20px">
            <label>提示弹窗文字</label>
            <input type="text" name="external_warning_text" value="<?php echo h($site['external_warning_text'] ?? '您即将离开本站，跳转到第三方网站，请注意安全'); ?>" placeholder="您即将离开本站...">
        </div>

        <button type="submit" class="btn btn-primary">💾 保存设置</button>
    </form>
</div>

<div class="card">
    <h3>📊 收录建议</h3>
    <ul style="color:#999;font-size:0.85rem;line-height:2;padding-left:20px">
        <li>确保 <a href="?page=seo" style="color:#6366f1">SEO设置</a> 中「允许搜索引擎爬取」已开启</li>
        <li>将 sitemap.xml 提交到 <a href="https://search.google.com/search-console" target="_blank" style="color:#6366f1">Google Search Console</a> 和 <a href="https://ziyuan.baidu.com" target="_blank" style="color:#6366f1">百度站长平台</a></li>
        <li>robots.txt 已自动生成，位于网站根目录</li>
        <li>每个页面都有规范的 meta description 和 title</li>
        <li>建议定期更新导航内容，保持站点活跃度</li>
    </ul>
</div>

<!-- 实时预览 -->
<?php if (!empty($site['avatar_url']) || !empty($site['bg_image']) || !empty($site['sub_title'])): ?>
<div class="card">
    <h3>👁️ 当前配置预览</h3>
    <div style="display:flex;gap:20px;flex-wrap:wrap;align-items:flex-start">
        <?php if (!empty($site['avatar_url'])): ?>
        <div style="text-align:center">
            <p style="color:#888;font-size:0.78rem;margin-bottom:6px">头像</p>
            <img src="<?php echo h($site['avatar_url']); ?>" style="width:80px;height:80px;border-radius:10px;object-fit:cover;border:2px solid rgba(255,255,255,.3)" onerror="this.src=''">
        </div>
        <?php endif; ?>
        <?php if (!empty($site['bg_image'])): ?>
        <div style="text-align:center">
            <p style="color:#888;font-size:0.78rem;margin-bottom:6px">背景图</p>
            <img src="<?php echo h($site['bg_image']); ?>" style="width:120px;height:80px;border-radius:8px;object-fit:cover;border:1px solid rgba(255,255,255,.2)">
        </div>
        <?php endif; ?>
        <?php if (!empty($site['sub_title'])): ?>
        <div>
            <p style="color:#888;font-size:0.78rem;margin-bottom:4px">副标题</p>
            <p style="color:#ccc;font-size:0.9rem"><?php echo h($site['sub_title']); ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>