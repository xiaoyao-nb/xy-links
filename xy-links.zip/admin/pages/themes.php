<?php
$db = Database::getInstance();
$action = $_GET['action'] ?? 'list';
$site = get_site_config();

// 切换主题
if (isset($_GET['set']) && !empty($_GET['set'])) {
    $theme_key = trim($_GET['set']);
    $exists = $db->fetch("SELECT id FROM themes WHERE theme_key=?", [$theme_key]);
    if ($exists) {
        $db->execute("UPDATE site_config SET current_theme=? WHERE id=?", [$theme_key, $site['id']]);
        $msg = ['type' => 'success', 'text' => '主题已切换！'];
        $site = get_site_config();
    }
}

// 保存自定义主题
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'save_custom') {
    $theme_name = trim($_POST['theme_name'] ?? '');
    $theme_key  = trim($_POST['theme_key'] ?? '') ?: preg_replace('/[^a-z0-9_]/', '_', strtolower($theme_name));

    $css_vars = json_encode([
        // 基础色
        '--bg-primary'      => $_POST['bg_primary']      ?? '#0a0a1a',
        '--bg-glass'        => $_POST['bg_glass']        ?? 'rgba(255,255,255,0.06)',
        '--bg-glass-hover'  => $_POST['bg_glass_hover']  ?? 'rgba(255,255,255,0.12)',
        '--text-primary'    => $_POST['text_primary']    ?? '#e8e8e8',
        '--text-secondary'  => $_POST['text_secondary']  ?? '#a0a0b0',
        '--accent-color'    => $_POST['accent_color']    ?? '#6366f1',
        '--accent-glow'     => $_POST['accent_glow']     ?? 'rgba(99,102,241,0.4)',
        '--border-color'    => $_POST['border_color']    ?? 'rgba(255,255,255,0.1)',
        '--card-shadow'     => $_POST['card_shadow']     ?? '0 8px 32px rgba(0,0,0,0.3)',
        '--backdrop-blur'   => $_POST['backdrop_blur']   ?? '16px',
        '--gradient-bg'     => $_POST['gradient_bg']     ?? 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)',
        '--card-radius'     => $_POST['card_radius']     ?? '16px',
        // v2.0 UI变量
        '--btn-height'      => $_POST['btn_height']      ?? '62px',
        '--btn-radius'      => $_POST['btn_radius']      ?? '14px',
        '--btn-gap'         => $_POST['btn_gap']         ?? '28px',
        '--avatar-size'     => $_POST['avatar_size']     ?? '140px',
        '--avatar-img-size' => $_POST['avatar_img_size'] ?? '120px',
        '--name-size'       => $_POST['name_size']       ?? '34px',
        '--container-max'   => $_POST['container_max']   ?? '560px',
        '--bg-overlay'      => $_POST['bg_overlay']      ?? 'rgba(0,0,0,0.45)',
        '--glow-spread'     => $_POST['glow_spread']     ?? '60px',
        '--anim-speed'      => $_POST['anim_speed']      ?? '1.2s',
        '--btn-font-size'   => $_POST['btn_font_size']   ?? '16px',
        '--line-color'      => $_POST['line_color']      ?? 'rgba(255,255,255,0.9)',
        '--hr-height'       => $_POST['hr_height']       ?? '1px',
        '--title-gradient'  => $_POST['title_gradient']  ?? 'linear-gradient(120deg,#ffffff,#f0f0f0,#ffffff)',
    ], JSON_UNESCAPED_SLASHES);

    if (empty($theme_name)) {
        $msg = ['type' => 'error', 'text' => '主题名称不能为空'];
    } else {
        $exists = $db->fetch("SELECT id FROM themes WHERE theme_key=?", [$theme_key]);
        if ($exists) {
            $db->execute("UPDATE themes SET theme_name=?, css_vars=? WHERE theme_key=?", [$theme_name, $css_vars, $theme_key]);
            $msg = ['type' => 'success', 'text' => '主题已更新！'];
        } else {
            $db->execute("INSERT INTO themes (theme_name,theme_key,css_vars,is_builtin) VALUES (?,?,?,0)", [$theme_name,$theme_key,$css_vars]);
            $msg = ['type' => 'success', 'text' => '自定义主题已创建！'];
        }
    }
}

// 删除自定义主题
if ($action === 'delete' && !empty($_GET['key'])) {
    $key = $_GET['key'];
    $theme = $db->fetch("SELECT * FROM themes WHERE theme_key=? AND is_builtin=0", [$key]);
    if ($theme) {
        if ($site['current_theme'] === $key) {
            $db->execute("UPDATE site_config SET current_theme='dark_glass' WHERE id=?", [$site['id']]);
        }
        $db->execute("DELETE FROM themes WHERE theme_key=?", [$key]);
        $msg = ['type' => 'success', 'text' => '主题已删除！'];
    }
}

$themes = $db->fetchAll("SELECT * FROM themes ORDER BY is_builtin DESC, id ASC");
$current_theme_key = $site['current_theme'] ?? 'dark_glass';
?>
<?php if (isset($msg)): ?>
<div class="alert alert-<?php echo $msg['type']==='success'?'success':'error'; ?>">
    <?php echo h($msg['text']); ?>
</div>
<?php endif; ?>

<!-- 主题列表 -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
    <h3 style="color:#fff;font-size:1rem">🎨 主题列表（共 <?php echo count($themes); ?> 个）</h3>
    <a href="?page=themes&action=custom" class="btn btn-primary">✨ 创建自定义主题</a>
</div>

<div class="theme-grid">
    <?php foreach ($themes as $theme): ?>
    <?php
    $vars = json_decode($theme['css_vars'], true);
    $is_current = ($current_theme_key === $theme['theme_key']);
    ?>
    <div class="theme-card <?php echo $is_current ? 'active' : ''; ?>">
        <span class="check">✓</span>

        <!-- 预览缩略图 -->
        <div style="height:100px;border-radius:10px;overflow:hidden;position:relative;margin-bottom:10px;
                     background:<?php echo $vars['--gradient-bg'] ?? '#333'; ?>;
                     border:1px solid <?php echo $vars['--border-color'] ?? 'rgba(255,255,255,.1)'; ?>">
            <!-- 模拟头像 -->
            <div style="position:absolute;top:10px;left:50%;transform:translateX(-50%);
                         width:30px;height:30px;border-radius:6px;background:<?php echo $vars['--accent-color'] ?? '#6366f1'; ?>;opacity:.8"></div>
            <!-- 模拟按钮 -->
            <div style="position:absolute;bottom:12px;left:50%;transform:translateX(-50%);display:flex;gap:6px">
                <div style="width:40px;height:14px;background:<?php echo $vars['--bg-glass'] ?? 'rgba(255,255,255,.06)'; ?>;border-radius:4px;border:1px solid <?php echo $vars['--border-color'] ?? 'rgba(255,255,255,.1)'; ?>"></div>
                <div style="width:40px;height:14px;background:<?php echo $vars['--bg-glass'] ?? 'rgba(255,255,255,.06)'; ?>;border-radius:4px;border:1px solid <?php echo $vars['--border-color'] ?? 'rgba(255,255,255,.1)'; ?>"></div>
            </div>
        </div>

        <div class="name"><?php echo h($theme['theme_name']); ?></div>
        <div class="tag">
            <?php echo $theme['is_builtin'] ? '🔒 内置主题' : '✏️ 自定义主题'; ?>
            · <code style="font-size:11px;color:#888"><?php echo h($theme['theme_key']); ?></code>
        </div>

        <div style="display:flex;gap:6px;margin-top:12px;flex-wrap:wrap">
            <?php if (!$is_current): ?>
            <a href="?page=themes&set=<?php echo h($theme['theme_key']); ?>" class="btn btn-sm btn-primary">✅ 使用</a>
            <?php else: ?>
            <span style="font-size:0.78rem;color:#6366f1;padding:4px 8px;background:rgba(99,102,241,.1);border-radius:4px">✓ 使用中</span>
            <?php endif; ?>

            <?php if (!$theme['is_builtin']): ?>
            <a href="?page=themes&action=custom&key=<?php echo h($theme['theme_key']); ?>" class="btn btn-sm" style="background:rgba(99,102,241,0.15);color:#a5b4fc">编辑</a>
            <a href="?page=themes&action=delete&key=<?php echo h($theme['theme_key']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除此主题？')">删除</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php if ($action === 'custom'): ?>
<?php
$edit_theme = null;
if (!empty($_GET['key'])) {
    $edit_theme = $db->fetch("SELECT * FROM themes WHERE theme_key=?", [$_GET['key']]);
    if ($edit_theme) $edit_vars = json_decode($edit_theme['css_vars'], true);
}
// 默认值
$dv = [
    '--bg-primary'=>'#0a0a1a','--bg-glass'=>'rgba(255,255,255,0.06)','--bg-glass-hover'=>'rgba(255,255,255,0.12)',
    '--text-primary'=>'#e8e8e8','--text-secondary'=>'#a0a0b0','--accent-color'=>'#6366f1',
    '--accent-glow'=>'rgba(99,102,241,0.4)','--border-color'=>'rgba(255,255,255,0.1)',
    '--card-shadow'=>'0 8px 32px rgba(0,0,0,0.3)','--backdrop-blur'=>'16px',
    '--gradient-bg'=>'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)','--card-radius'=>'16px',
    '--btn-height'=>'62px','--btn-radius'=>'14px','--btn-gap'=>'28px',
    '--avatar-size'=>'140px','--avatar-img-size'=>'120px','--name-size'=>'34px',
    '--container-max'=>'560px','--bg-overlay'=>'rgba(0,0,0,0.45)','--glow-spread'=>'60px',
    '--anim-speed'=>'1.2s','--btn-font-size'=>'16px','--line-color'=>'rgba(255,255,255,0.9)',
    '--hr-height'=>'1px','--title-gradient'=>'linear-gradient(120deg,#ffffff,#f0f0f0,#ffffff)'
];
$ev = array_merge($dv, $edit_vars ?? []);
?>
<div class="card" style="margin-top:28px">
    <h3><?php echo $edit_theme ? '✏️ 编辑主题：'.h($edit_theme['theme_name']) : '✨ 创建自定义主题'; ?></h3>
    <p style="color:#888;font-size:0.82rem;margin-bottom:24px">所有字段均可修改，实时预览帮你调出完美效果</p>

    <form method="POST" action="?page=themes&action=save_custom">
        <div class="form-row">
            <div class="form-group"><label>主题名称</label>
                <input type="text" name="theme_name" required value="<?php echo h($edit_theme['theme_name'] ?? ''); ?>" placeholder="如：我的暗夜紫">
            </div>
            <div class="form-group"><label>主题标识（英文/数字/下划线）</label>
                <input type="text" name="theme_key" value="<?php echo h($edit_theme['theme_key'] ?? ''); ?>" placeholder="my_theme_01" pattern="[a-z0-9_]+">
            </div>
        </div>

        <h4 style="color:#aaa;margin:20px 0 12px;font-size:0.85rem;border-left:3px solid #6366f1;padding-left:10px">🎨 颜色配置</h4>

        <div class="form-row">
            <div class="form-group"><label>主背景色</label><input type="text" name="bg_primary" value="<?php echo h($ev['--bg-primary']); ?>"></div>
            <div class="form-group"><label>毛玻璃背景</label><input type="text" name="bg_glass" value="<?php echo h($ev['--bg-glass']); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>悬停背景</label><input type="text" name="bg_glass_hover" value="<?php echo h($ev['--bg-glass-hover']); ?>"></div>
            <div class="form-group"><label>主文字色</label><input type="text" name="text_primary" value="<?php echo h($ev['--text-primary']); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>次文字色</label><input type="text" name="text_secondary" value="<?php echo h($ev['--text-secondary']); ?>"></div>
            <div class="form-group"><label>⭐ 强调色（主色调）</label><input type="text" name="accent_color" value="<?php echo h($ev['--accent-color']); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>强调发光色</label><input type="text" name="accent_glow" value="<?php echo h($ev['--accent-glow']); ?>"></div>
            <div class="form-group"><label>边框颜色</label><input type="text" name="border_color" value="<?php echo h($ev['--border-color']); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>标题渐变色</label><input type="text" name="title_gradient" value="<?php echo h($ev['--title-gradient']); ?>" placeholder="linear-gradient(120deg,#fff,#ccc,#fff)"></div>
            <div class="form-group"><label>分割线颜色</label><input type="text" name="line_color" value="<?php echo h($ev['--line-color']); ?>"></div>
        </div>

        <h4 style="color:#aaa;margin:20px 0 12px;font-size:0.85rem;border-left:3px solid #6366f1;padding-left:10px">🌈 背景与阴影</h4>

        <div class="form-row">
            <div class="form-group"><label>整体渐变背景</label><input type="text" name="gradient_bg" value="<?php echo h($ev['--gradient-bg']); ?>" placeholder="linear-gradient(135deg, #000 0%, #222 100%)"></div>
            <div class="form-group"><label>背景遮罩层</label><input type="text" name="bg_overlay" value="<?php echo h($ev['--bg-overlay']); ?>" placeholder="rgba(0,0,0,0.45)"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>卡片阴影</label><input type="text" name="card_shadow" value="<?php echo h($ev['--card-shadow']); ?>"></div>
            <div class="form-group"><label>毛玻璃模糊度</label><input type="text" name="backdrop_blur" value="<?php echo h($ev['--backdrop-blur']); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>光晕扩散范围</label><input type="text" name="glow_spread" value="<?php echo h($ev['--glow-spread']); ?>" placeholder="60px"></div>
            <div class="form-group"><label>分割线高度</label><input type="text" name="hr_height" value="<?php echo h($ev['--hr-height']); ?>" placeholder="1px"></div>
        </div>

        <h4 style="color:#aaa;margin:20px 0 12px;font-size:0.85rem;border-left:3px solid #6366f1;padding-left:10px">📐 布局与尺寸</h4>

        <div class="form-row">
            <div class="form-group"><label>按钮高度</label><input type="text" name="btn_height" value="<?php echo h($ev['--btn-height']); ?>" placeholder="62px"></div>
            <div class="form-group"><label>按钮圆角</label><input type="text" name="btn_radius" value="<?php echo h($ev['--btn-radius']); ?>" placeholder="14px"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>按钮间距</label><input type="text" name="btn_gap" value="<?php echo h($ev['--btn-gap']); ?>" placeholder="28px"></div>
            <div class="form-group"><label>按钮字号</label><input type="text" name="btn_font_size" value="<?php echo h($ev['--btn-font-size']); ?>" placeholder="16px"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>头像容器尺寸</label><input type="text" name="avatar_size" value="<?php echo h($ev['--avatar-size']); ?>" placeholder="140px"></div>
            <div class="form-group"><label>头像图片尺寸</label><input type="text" name="avatar_img_size" value="<?php echo h($ev['--avatar-img-size']); ?>" placeholder="120px"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>标题字号</label><input type="text" name="name_size" value="<?php echo h($ev['--name-size']); ?>" placeholder="34px"></div>
            <div class="form-group"><label>容器最大宽度</label><input type="text" name="container_max" value="<?php echo h($ev['--container-max']); ?>" placeholder="560px"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>卡片圆角</label><input type="text" name="card_radius" value="<?php echo h($ev['--card-radius']); ?>" placeholder="16px"></div>
            <div class="form-group"><label>动画速度</label><input type="text" name="anim_speed" value="<?php echo h($ev['--anim-speed']); ?>" placeholder="1.2s"></div>
        </div>

        <!-- 实时预览 -->
        <div style="margin:24px 0;padding:28px;border-radius:14px;border:1px solid <?php echo h($ev['--border-color']); ?>;
                    background:<?php echo h($ev['--gradient-bg']); ?>;position:relative;overflow:hidden">
            <p style="color:<?php echo h($ev['--text-primary']); ?>;font-size:1.3rem;font-weight:bold;margin-bottom:4px
                    ;background:<?php echo h($ev['--title-gradient']); ?>;-webkit-background-clip:text;color:transparent;
                    display:inline-block">预览标题</p>
            <p style="color:<?php echo h($ev['--text-secondary']); ?>;font-size:13px;margin-bottom:16px">这里是副标题描述文字</p>

            <div style="display:flex;gap:<?php echo h($ev['--btn-gap']); ?>;flex-wrap:wrap;align-items:center">
                <div style="height:<?php echo h($ev['--btn-height']); ?>;padding:0 24px;display:flex;align-items:center;
                             background:<?php echo h($ev['--bg-glass']); ?>;border:2px solid <?php echo h($ev['--border-color']); ?>;
                             border-radius:<?php echo h($ev['--btn-radius']); ?>;color:<?php echo h($ev['--text-primary']); ?>;
                             font-size:<?php echo h($ev['--btn-font-size']); ?>;backdrop-filter:blur(<?php echo h($ev['--backdrop-blur']); ?>)">
                    导航按钮 A
                </div>
                <div style="height:<?php echo h($ev['--btn-height']); ?>;padding:0 24px;display:flex;align-items:center;
                             background:<?php echo h($ev['--accent-color']); ?>;border-radius:<?php echo h($ev['--btn-radius']); ?>;
                             color:#fff;font-size:<?php echo h($ev['--btn-font-size']); ?>;box-shadow:0 0 15px <?php echo h($ev['--accent-glow']); ?>">
                    强调按钮
                </div>
                <div style="width:<?php echo h($ev['--avatar-img-size']); ?>;height:<?php echo h($ev['--avatar-img-size']); ?>;
                             background:<?php echo h($ev['--accent-color']); ?>;border-radius:8px;display:flex;align-items:center;justify-content:center;
                             color:#fff;font-size:28px;font-weight:bold">
                    A
                </div>
            </div>
        </div>

        <div style="display:flex;gap:10px;align-items:center">
            <button type="submit" class="btn btn-primary">💾 保存主题</button>
            <a href="?page=themes" class="btn btn-danger" style="line-height:1.5;text-decoration:none">取消</a>
        </div>
    </form>
</div>
<?php endif; ?>