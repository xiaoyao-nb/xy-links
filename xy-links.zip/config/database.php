<?php
/**
 * 数据库配置文件 - 请根据实际环境修改
 * 修改后重命名为 database.php
 */

define('DB_HOST', 'localhost');         // 数据库地址
define('DB_PORT', '3306');              // 数据库端口
define('DB_NAME', 'nav_site');          // 数据库名
define('DB_USER', 'root');              // 数据库用户名
define('DB_PASS', 'your_password');     // 数据库密码
define('DB_CHARSET', 'utf8mb4');        // 字符集

// 站点配置
define('SITE_URL', 'https://yourdomain.com');  // 你的域名
define('ADMIN_PATH', '/admin');                // 后台路径
define('DEBUG_MODE', false);                   // 调试模式

/**
 * 数据库连接类
 */
class Database {
    private static $instance = null;
    private $conn;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $this->conn = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            if (DEBUG_MODE) {
                die("数据库连接失败: " . $e->getMessage());
            }
            die("系统维护中，请稍后再试。");
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->conn;
    }
    
    // 查询多条
    public function fetchAll($sql, $params = []) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    // 查询单条
    public function fetch($sql, $params = []) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }
    
    // 执行（增删改）
    public function execute($sql, $params = []) {
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute($params);
    }
    
    // 获取最后插入ID
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }
    
    // 获取影响行数
    public function rowCount($sql, $params = []) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }
}
