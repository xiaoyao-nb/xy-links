<?php
/**
 * 通用函数库 v2.0
 */

// 安全输出
function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// 获取SEO配置
function get_seo_config() {
    $db = Database::getInstance();
    return $db->fetch("SELECT * FROM seo_config ORDER BY id DESC LIMIT 1");
}

// 获取站点配置
function get_site_config() {
    $db = Database::getInstance();
    return $db->fetch("SELECT * FROM site_config ORDER BY id DESC LIMIT 1");
}

// 获取所有导航链接（按分类分组）
function get_nav_links() {
    $db = Database::getInstance();
    $links = $db->fetchAll("SELECT * FROM nav_links WHERE status=1 ORDER BY sort_order ASC, id ASC");
    $grouped = [];
    foreach ($links as $link) {
        $cat = $link['category'] ?: '其他';
        $grouped[$cat][] = $link;
    }
    return $grouped;
}

// 获取所有分类
function get_categories() {
    $db = Database::getInstance();
    return $db->fetchAll("SELECT * FROM nav_categories ORDER BY sort_order ASC");
}

// 获取当前主题CSS变量（v2.0 扩展更多UI变量）
function get_current_theme() {
    $db = Database::getInstance();
    $site = get_site_config();
    $theme_key = $site['current_theme'] ?? 'dark_glass';

    $theme = $db->fetch("SELECT * FROM themes WHERE theme_key = ?", [$theme_key]);
    if ($theme) {
        return json_decode($theme['css_vars'], true);
    }
    // 默认主题（暗黑毛玻璃）
    return default_theme_vars();
}

// 默认主题变量
function default_theme_vars() {
    return [
        '--bg-primary'         => '#0a0a1a',
        '--bg-glass'          => 'rgba(255,255,255,0.06)',
        '--bg-glass-hover'    => 'rgba(255,255,255,0.12)',
        '--text-primary'      => '#e8e8e8',
        '--text-secondary'    => '#a0a0b0',
        '--accent-color'      => '#6366f1',
        '--accent-glow'       => 'rgba(99,102,241,0.4)',
        '--border-color'      => 'rgba(255,255,255,0.1)',
        '--card-shadow'       => '0 8px 32px rgba(0,0,0,0.3)',
        '--backdrop-blur'     => '16px',
        '--gradient-bg'       => 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)',
        '--card-radius'       => '16px',
        // v2.0 新增UI专用变量
        '--btn-height'        => '62px',
        '--btn-radius'        => '14px',
        '--btn-gap'           => '28px',
        '--avatar-size'       => '140px',
        '--avatar-img-size'   => '120px',
        '--name-size'         => '34px',
        '--container-max'     => '560px',
        '--bg-overlay'        => 'rgba(0,0,0,0.45)',
        '--glow-spread'       => '60px',
        '--anim-speed'        => '1.2s',
        '--btn-font-size'     => '16px',
        '--line-color'        => 'rgba(255,255,255,0.9)',
        '--hr-height'         => '1px',
        '--title-gradient'    => 'linear-gradient(120deg,#fff,#f0f0f0,#fff)',
    ];
}

// 检查登录状态
function check_login() {
    session_start();
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        header('Location: login.php');
        exit;
    }
}

// 生成sitemap.xml内容
function generate_sitemap() {
    $db = Database::getInstance();
    $links = $db->fetchAll("SELECT * FROM nav_links WHERE status=1");
    $site_url = SITE_URL;
    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    $xml .= "  <url>\n    <loc>{$site_url}/</loc>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n";
    foreach ($links as $link) {
        $xml .= "  <url>\n    <loc>{$site_url}/?link=" . $link['id'] . "</loc>\n";
        $xml .= "    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>\n";
    }
    $xml .= '</urlset>';
    return $xml;
}