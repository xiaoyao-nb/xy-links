<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$seo     = get_seo_config();
$site    = get_site_config();
$theme   = get_current_theme();
$nav_data   = get_nav_links();
$categories = get_categories();

// 生成CSS变量
$css_vars = '';
foreach ($theme as $k => $v) { $css_vars .= "$k:$v;\n  "; }

$robots_meta = ($seo['allow_robots'] ?? 1) ? 'index, follow' : 'noindex, nofollow';

// 头像URL（后台可配，留空用默认）
$avatar_url = !empty($site['avatar_url']) ? $site['avatar_url'] : '';
// 背景图URL（后台可配，留空用渐变）
$bg_image   = !empty($site['bg_image']) ? $site['bg_image'] : '';
// 站点名称
$site_name  = $seo['site_title'] ?? '我的导航页';
// 副标题
$sub_title  = !empty($site['sub_title']) ? $site['sub_title'] : ($seo['site_description'] ?? '简洁 · 实用 · 高效工具导航');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="description" content="<?php echo h($seo['site_description'] ?? ''); ?>">
<meta name="keywords" content="<?php echo h($seo['site_keywords'] ?? ''); ?>">
<meta name="robots" content="<?php echo $robots_meta; ?>">
<meta name="generator" content="NavSite v2.0">
<link rel="canonical" href="<?php echo SITE_URL; ?>/">

<!-- Open Graph -->
<meta property="og:title" content="<?php echo h($site_name); ?>">
<meta property="og:description" content="<?php echo h($seo['site_description'] ?? ''); ?>">
<meta property="og:type" content="website">
<meta property="og:url" content="<?php echo SITE_URL; ?>/">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo h($site_name); ?>">
<meta name="twitter:description" content="<?php echo h($seo['site_description'] ?? ''); ?>">

<title><?php echo h($site_name); ?></title>

<style>
:root{
  <?php echo $css_vars; ?>
  /* 新增UI专用变量（主题也可覆盖） */
  --btn-height:62px;
  --btn-radius:14px;
  --btn-gap:28px;
  --avatar-size:140px;
  --avatar-img-size:120px;
  --name-size:34px;
  --container-max:560px;
  --bg-overlay:rgba(0,0,0,0.45);
  --glow-spread:60px;
  --anim-speed:1.2s;
}

*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei","PingFang SC",-apple-system,BlinkMacSystemFont,sans-serif}

body{
  min-height:100vh;
  overflow-x:hidden;
  background:#0a0a1a;
}

/* ===== 背景层 ===== */
.bg-container{
  width:100%;
  min-height:100vh;
  padding:50px 20px;
  background-image:
    linear-gradient(var(--bg-overlay), var(--bg-overlay)),
    <?php if ($bg_image): ?>
    url("<?php echo h($bg_image); ?>")
    <?php else: ?>
    var(--gradient-bg)
    <?php endif; ?>
    ;
  background-size:cover;
  background-position:center;
  background-repeat:no-repeat;
  background-attachment:fixed;
  display:flex;
  flex-direction:column;
  align-items:center;
  animation:fadeIn var(--anim-speed) ease-in-out;
  position:relative;
}

/* 柔和光晕 */
.bg-container::after{
  content:'';
  position:absolute;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
  width:80%;height:80%;
  border-radius:20px;
  box-shadow:0 0 var(--glow-spread) rgba(255,255,255,0.05);
  z-index:0;pointer-events:none;
}

/* 漂浮粒子 */
.bg-particles{position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1;overflow:hidden}
.particle{position:absolute;border-radius:50%;background:var(--accent-color);opacity:.08;animation:float linear infinite}
@keyframes float{0%{transform:translateY(100vh) scale(0);opacity:0}10%{opacity:.08}90%{opacity:.08}100%{transform:translateY(-10vh) scale(1);opacity:0}}

.main-page{
  width:100%;
  max-width:var(--container-max);
  display:flex;
  flex-direction:column;
  align-items:center;
  position:relative;
  z-index:2;
}

/* ===== 头像 ===== */
.avatar-container{
  width:var(--avatar-size);
  height:var(--avatar-size);
  border:2px solid rgba(255,255,255,.9);
  border-radius:12px;
  display:flex;align-items:center;justify-content:center;
  margin-bottom:20px;
  animation:borderBlink 2.5s ease-in-out infinite;
  background:rgba(255,255,255,0.05);
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
  overflow:hidden;
}
.avatar-container img{
  width:var(--avatar-img-size);
  height:var(--avatar-img-size);
  border-radius:8px;
  object-fit:cover;
  box-shadow:0 0 15px rgba(0,0,0,.3);
}
@keyframes borderBlink{
  0%,100%{border-color:#fff;box-shadow:0 0 12px rgba(255,255,255,.7)}
  50%{border-color:rgba(255,255,255,.5);box-shadow:0 0 8px rgba(255,255,255,.4)}
}

/* ===== 标题 ===== */
.name-wrap{text-align:center;margin-bottom:30px}
h1{
  font-size:var(--name-size);
  font-weight:700;
  letter-spacing:3px;
  margin:0;
  background:linear-gradient(120deg,#fff,#f0f0f0,#fff);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  background-size:200% auto;
  animation:nameFloat 3s ease-in-out infinite, textShine 6s ease-in-out infinite;
  text-shadow:0 2px 10px rgba(0,0,0,.2);
}
.name-sub{
  font-size:14px;
  color:rgba(255,255,255,.7);
  margin-top:8px;letter-spacing:1px;
  animation:nameFade 4s ease-in-out infinite;
}
@keyframes nameFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
@keyframes textShine{to{background-position:200% center}}
@keyframes nameFade{0%,100%{opacity:.7}50%{opacity:1}}

/* ===== 分割线 ===== */
hr{
  width:100%;max-width:var(--container-max);
  border:none;height:1px;margin:25px 0;
  background:linear-gradient(90deg,transparent,rgba(255,255,255,.9),transparent);
  background-size:200% auto;
  animation:lineFlow 4s linear infinite;
}
@keyframes lineFlow{0%{background-position:-100% center}100%{background-position:100% center}}

/* ===== 搜索框 ===== */
.search-wrap{width:100%;max-width:var(--container-max);margin-bottom:10px;position:relative;z-index:2}
.search-box{
  width:100%;
  padding:14px 22px;
  background:rgba(255,255,255,0.08);
  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
  border:1px solid rgba(255,255,255,.25);
  border-radius:50px;
  color:#fff;font-size:15px;outline:none;
  transition:all .3s ease;
}
.search-box:focus{border-color:var(--accent-color);box-shadow:0 0 20px var(--accent-glow)}
.search-box::placeholder{color:rgba(255,255,255,.5)}

/* ===== 分类标签 ===== */
.cat-tabs{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-bottom:20px;position:relative;z-index:2}
.cat-tab{
  padding:6px 18px;
  background:rgba(255,255,255,.06);
  backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
  border:1px solid rgba(255,255,255,.15);
  border-radius:30px;
  color:rgba(255,255,255,.7);
  cursor:pointer;font-size:13px;
  transition:all .3s ease;
}
.cat-tab:hover,.cat-tab.active{
  background:var(--accent-color);color:#fff;border-color:var(--accent-color);
  box-shadow:0 0 15px var(--accent-glow);
}

/* ===== 3D按钮网格 ===== */
.button-container{
  width:100%;
  max-width:var(--container-max);
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:var(--btn-gap);
  margin:10px 0;
  position:relative;z-index:2;
}

.btn-3d{
  display:flex;align-items:center;justify-content:center;gap:10px;
  height:var(--btn-height);
  border:2px solid rgba(255,255,255,.8);
  background:rgba(255,255,255,0.03);
  backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
  border-radius:var(--btn-radius);
  color:#fff;text-decoration:none;font-size:16px;font-weight:500;
  text-shadow:0 1px 8px rgba(0,0,0,.3);
  transition:all .35s cubic-bezier(.34,1.56,.64,1);
  position:relative;overflow:hidden;
  opacity:0;
  animation:btnFade .6s ease forwards;
  transform-style:preserve-3d;perspective:500px;
  box-shadow:
    0 10px 20px rgba(0,0,0,.3),
    0 6px 6px rgba(0,0,0,.2),
    inset 0 1px 0 rgba(255,255,255,.15),
    0 0 0 1px rgba(255,255,255,.08);
}
.btn-3d .btn-icon{
  width:28px;height:28px;border-radius:6px;object-fit:cover;
  background:rgba(255,255,255,.1);padding:2px;
}
.btn-3d .btn-icon-fallback{
  width:28px;height:28px;border-radius:6px;
  display:flex;align-items:center;justify-content:center;
  background:var(--accent-color);color:#fff;font-size:14px;font-weight:bold;
}
.btn-3d::before{
  content:'';position:absolute;top:0;left:0;width:100%;height:100%;
  background:linear-gradient(135deg,rgba(255,255,255,.1),rgba(255,255,255,.03));
  opacity:0;transition:opacity .3s ease;z-index:-1;
}
.btn-3d::after{
  content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;
  background:linear-gradient(45deg,transparent,rgba(255,255,255,.08),transparent);
  transform:rotate(45deg);transition:all .5s ease;z-index:-1;
}
.btn-3d:hover{
  transform:translateY(-8px) rotateX(5deg) scale(1.05);
  box-shadow:
    0 15px 30px rgba(0,0,0,.4),
    0 10px 10px rgba(0,0,0,.3),
    0 0 25px var(--accent-glow),
    inset 0 1px 0 rgba(255,255,255,.25),
    0 0 0 1px rgba(255,255,255,.2);
  border-color:var(--accent-color);
  background:rgba(255,255,255,0.08);
}
.btn-3d:hover::before{opacity:1}
.btn-3d:hover::after{left:100%}
.btn-3d:active{
  transform:translateY(-4px) rotateX(2deg) scale(1.02);
  box-shadow:0 8px 15px rgba(0,0,0,.3),0 5px 5px rgba(0,0,0,.2),0 0 10px var(--accent-glow);
  transition:all .1s ease;
}

/* 错落入场动画 */
.button-container a:nth-child(1){animation-delay:.05s}
.button-container a:nth-child(2){animation-delay:.12s}
.button-container a:nth-child(3){animation-delay:.19s}
.button-container a:nth-child(4){animation-delay:.26s}
.button-container a:nth-child(5){animation-delay:.33s}
.button-container a:nth-child(6){animation-delay:.40s}
.button-container a:nth-child(7){animation-delay:.47s}
.button-container a:nth-child(8){animation-delay:.54s}
.button-container a:nth-child(9){animation-delay:.61s}
.button-container a:nth-child(10){animation-delay:.68s}

@keyframes btnFade{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}

/* ===== 空状态 ===== */
.empty-state{text-align:center;padding:40px 20px;color:rgba(255,255,255,.6);position:relative;z-index:2}
.empty-state .icon{font-size:48px;margin-bottom:12px;opacity:.5}

/* ===== 底部 ===== */
.footer-info{
  color:rgba(255,255,255,.85);
  font-size:14px;
  text-shadow:0 1px 8px rgba(0,0,0,.3);
  margin-top:20px;
  position:relative;z-index:2;
  text-align:center;
  animation:infoBlink 5s ease-in-out infinite;
  line-height:1.8;
}
.footer-info a{color:rgba(255,255,255,.85);text-decoration:none}
.footer-info a:hover{color:#fff;text-decoration:underline}
.footer-extra{font-size:12px;opacity:.6;margin-top:4px}

@keyframes infoBlink{0%,100%{opacity:.85}50%{opacity:1;color:#fff}}

/* ===== 管理入口 ===== */
.admin-link{
  position:fixed;bottom:20px;right:20px;z-index:100;
  width:44px;height:44px;border-radius:50%;
  background:rgba(255,255,255,.08);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
  border:1px solid rgba(255,255,255,.2);
  display:flex;align-items:center;justify-content:center;
  cursor:pointer;transition:all .3s;text-decoration:none;color:rgba(255,255,255,.7);font-size:20px;
}
.admin-link:hover{background:var(--accent-color);color:#fff;box-shadow:0 0 15px var(--accent-glow);border-color:var(--accent-color)}

/* ===== 外站跳转弹窗 ===== */
.modal-overlay{
  display:none;position:fixed;top:0;left:0;width:100%;height:100%;
  background:rgba(0,0,0,.65);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  z-index:9999;align-items:center;justify-content:center;
  animation:fadeIn .2s ease;
}
.modal-overlay.show{display:flex}
.modal-box{
  background:rgba(20,20,40,.95);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);
  border:1px solid rgba(255,255,255,.15);
  border-radius:20px;padding:36px 32px;
  max-width:420px;width:90%;text-align:center;
  box-shadow:0 20px 60px rgba(0,0,0,.5),0 0 40px var(--accent-glow);
  animation:popIn .3s cubic-bezier(.4,0,.2,1);
}
.modal-icon{font-size:48px;margin-bottom:16px}
.modal-title{font-size:20px;font-weight:700;margin-bottom:10px;color:#fff}
.modal-text{color:rgba(255,255,255,.7);font-size:14px;line-height:1.6;margin-bottom:18px}
.modal-url{display:inline-block;padding:6px 14px;background:rgba(255,255,255,.08);border-radius:8px;color:var(--accent-color);font-size:13px;margin-bottom:20px;word-break:break-all;max-width:100%}
.modal-buttons{display:flex;gap:12px;justify-content:center}
.btn{padding:10px 28px;border-radius:12px;border:none;cursor:pointer;font-size:15px;font-weight:600;transition:all .3s}
.btn-confirm{background:var(--accent-color);color:#fff;box-shadow:0 0 15px var(--accent-glow)}
.btn-confirm:hover{filter:brightness(1.15);transform:scale(1.05)}
.btn-cancel{background:rgba(255,255,255,.08);color:rgba(255,255,255,.7);border:1px solid rgba(255,255,255,.2)}
.btn-cancel:hover{background:rgba(255,255,255,.15);color:#fff}

@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes popIn{from{opacity:0;transform:scale(.85)}to{opacity:1;transform:scale(1)}}

/* ===== 分类区块（多分类时） ===== */
.nav-section{width:100%;max-width:var(--container-max);position:relative;z-index:2;margin-bottom:10px}
.nav-section h2{
  font-size:15px;color:rgba(255,255,255,.9);margin-bottom:14px;
  padding-left:12px;border-left:3px solid var(--accent-color);
  text-shadow:0 1px 4px rgba(0,0,0,.3);
}
.nav-section.hidden{display:none}

/* ===== 响应式 ===== */
@media(max-width:600px){
  :root{--avatar-size:110px;--avatar-img-size:92px;--name-size:26px;--btn-height:54px;--btn-gap:18px;--btn-radius:12px}
  .bg-container{padding:30px 14px}
  .button-container{grid-template-columns:1fr}
  .modal-box{padding:28px 20px}
}

/* ===== 搜索无结果 ===== */
.no-result{display:none;text-align:center;padding:20px;color:rgba(255,255,255,.4);font-size:14px}
</style>
</head>
<body>

<!-- 背景粒子 -->
<div class="bg-particles" id="particles"></div>

<!-- 页面主体 -->
<div class="bg-container">
  <div class="main-page" id="mainPage">

    <!-- 头像 -->
    <div class="avatar-container">
      <?php if ($avatar_url): ?>
        <img id="avatarImg" src="<?php echo h($avatar_url); ?>" alt="头像" onerror="avatarFallback()">
      <?php else: ?>
        <div style="width:var(--avatar-img-size);height:var(--avatar-img-size);border-radius:8px;display:flex;align-items:center;justify-content:center;background:var(--accent-color);color:#fff;font-size:42px;font-weight:bold;text-shadow:0 2px 8px rgba(0,0,0,.3)"><?php echo mb_substr(h($site_name),0,1); ?></div>
      <?php endif; ?>
    </div>

    <!-- 标题 -->
    <div class="name-wrap">
      <h1><?php echo h($site_name); ?></h1>
      <p class="name-sub"><?php echo h($sub_title); ?></p>
    </div>

    <hr>

    <!-- 搜索 -->
    <div class="search-wrap">
      <input type="text" class="search-box" id="searchInput" placeholder="🔍 搜索导航..." oninput="filterNav()">
    </div>

    <!-- 分类标签 -->
    <?php if (count($categories) > 1 || !empty($nav_data) && count($nav_data) > 1): ?>
    <div class="cat-tabs" id="catTabs">
      <div class="cat-tab active" data-cat="all">全部</div>
      <?php foreach ($categories as $cat): ?>
      <div class="cat-tab" data-cat="<?php echo h($cat['name']); ?>"><?php echo h($cat['name']); ?></div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- 无结果提示 -->
    <div class="no-result" id="noResult">🔍 没有找到匹配的导航</div>

    <!-- 导航内容 -->
    <?php if (empty($nav_data)): ?>
    <div class="empty-state">
      <div class="icon">📭</div>
      <p>还没有添加导航链接，请到后台管理添加</p>
    </div>
    <?php endif; ?>

    <?php foreach ($nav_data as $category => $links): ?>
    <section class="nav-section" data-category="<?php echo h($category); ?>">
      <?php if (count($nav_data) > 1): ?>
      <h2><?php echo h($category); ?></h2>
      <?php endif; ?>
      <div class="button-container">
        <?php foreach ($links as $link): ?>
        <a href="<?php echo h($link['url']); ?>"
           class="btn-3d"
           <?php if ($link['is_external']): ?>
           data-href="<?php echo h($link['url']); ?>"
           data-title="<?php echo h($link['title']); ?>"
           onclick="return handleExternalLink(this,event)"
           <?php endif; ?>
           title="<?php echo h($link['description'] ?? ''); ?>">

          <?php if (!empty($link['icon'])): ?>
            <img class="btn-icon" src="<?php echo h($link['icon']); ?>" alt=""
                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div class="btn-icon-fallback" style="display:none"><?php echo mb_substr(h($link['title']),0,1); ?></div>
          <?php else: ?>
            <div class="btn-icon-fallback"><?php echo mb_substr(h($link['title']),0,1); ?></div>
          <?php endif; ?>

          <span><?php echo h($link['title']); ?></span>
        </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endforeach; ?>

    <hr>

    <!-- 底部信息 -->
    <div class="footer-info">
      <?php if (!empty($site['beian_number'])): ?>
        <p>
          <a href="<?php echo h($site['beian_link'] ?: 'https://beian.miit.gov.cn'); ?>" target="_blank" rel="noopener noreferrer">
            <?php echo h($site['beian_number']); ?>
          </a>
        </p>
      <?php endif; ?>
      <p><?php echo h($site['copyright_text'] ?? ''); ?></p>
      <?php if (!empty($site['footer_extra'])): ?>
      <p class="footer-extra"><?php echo h($site['footer_extra']); ?></p>
      <?php endif; ?>
    </div>

  </div><!-- /main-page -->
</div><!-- /bg-container -->

<!-- 管理入口 -->
<a href="admin/" class="admin-link" title="后台管理">⚙️</a>

<!-- 外站跳转弹窗 -->
<div class="modal-overlay" id="externalModal">
  <div class="modal-box">
    <div class="modal-icon">⚠️</div>
    <div class="modal-title">即将离开本站</div>
    <div class="modal-text" id="modalText"><?php echo h($site['external_warning_text'] ?? '您即将离开本站，跳转到第三方网站，请注意安全'); ?></div>
    <div class="modal-url" id="modalUrl"></div>
    <div class="modal-buttons">
      <button class="btn btn-cancel" onclick="closeModal()">取消</button>
      <button class="btn btn-confirm" onclick="confirmJump()">确定前往</button>
    </div>
  </div>
</div>

<script>
/* 背景粒子 */
(function(){
  const c=document.getElementById('particles'),n=18;
  for(let i=0;i<n;i++){
    const p=document.createElement('div');p.className='particle';
    const s=Math.random()*5+2;
    p.style.cssText=`width:${s}px;height:${s}px;left:${Math.random()*100}%;animation-duration:${Math.random()*15+10}s;animation-delay:${Math.random()*20}s`;
    c.appendChild(p);
  }
})();

/* 头像加载失败回退 */
function avatarFallback(){
  const c=document.querySelector('.avatar-container');
  const initial='<?php echo mb_substr(h($site_name),0,1); ?>';
  if(c && !c.querySelector('.avatar-fallback')){
    const d=document.createElement('div');
    d.className='avatar-fallback';
    d.style.cssText='width:var(--avatar-img-size);height:var(--avatar-img-size);border-radius:8px;display:flex;align-items:center;justify-content:center;background:var(--accent-color);color:#fff;font-size:42px;font-weight:bold;text-shadow:0 2px 8px rgba(0,0,0,.3)';
    d.textContent=initial;
    c.appendChild(d);
    const img=c.querySelector('img');
    if(img) img.remove();
  }
}

/* 外站跳转 */
let pendingUrl='';
function handleExternalLink(el,ev){
  <?php if ($site['external_warning'] ?? 1): ?>
  ev.preventDefault();
  pendingUrl=el.getAttribute('data-href');
  document.getElementById('modalUrl').textContent=pendingUrl;
  document.getElementById('externalModal').classList.add('show');
  return false;
  <?php else: ?>
  return true;
  <?php endif; ?>
}
function closeModal(){document.getElementById('externalModal').classList.remove('show');pendingUrl=''}
function confirmJump(){if(pendingUrl){window.open(pendingUrl,'_blank','noopener,noreferrer')}closeModal()}
document.getElementById('externalModal').addEventListener('click',e=>{if(e.target===this)closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});

/* 搜索过滤 */
function filterNav(){
  const q=document.getElementById('searchInput').value.toLowerCase().trim();
  const sections=document.querySelectorAll('.nav-section');
  let totalVisible=0;
  sections.forEach(sec=>{
    const btns=sec.querySelectorAll('.btn-3d');
    let vis=0;
    btns.forEach(b=>{
      const t=b.textContent.toLowerCase();
      const m=!q||t.includes(q);
      b.style.display=m?'':'none';
      if(m)vis++;
    });
    sec.classList.toggle('hidden',vis===0);
    totalVisible+=vis;
  });
  document.getElementById('noResult').style.display=totalVisible===0&&q?'block':'none';
}

/* 分类切换 */
document.querySelectorAll('.cat-tab').forEach(tab=>{
  tab.addEventListener('click',function(){
    document.querySelectorAll('.cat-tab').forEach(t=>t.classList.remove('active'));
    this.classList.add('active');
    const cat=this.getAttribute('data-cat');
    document.querySelectorAll('.nav-section').forEach(sec=>{
      sec.classList.toggle('hidden',!(cat==='all'||sec.getAttribute('data-category')===cat));
    });
  });
});

/* 按钮按下效果 */
document.querySelectorAll('.btn-3d').forEach(b=>{
  b.addEventListener('mousedown',()=>b.style.transform='translateY(-2px) rotateX(2deg) scale(1.02)');
  b.addEventListener('mouseup',()=>b.style.transform='');
});
</script>

</body>
</html>