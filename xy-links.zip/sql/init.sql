-- ============================================
-- 个人导航页  数据库初始化脚本
-- ============================================
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS nav_site DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE nav_site;

-- 导航链接表
CREATE TABLE IF NOT EXISTS `nav_links` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(100) NOT NULL COMMENT '网站名称',
  `url` VARCHAR(500) NOT NULL COMMENT '网站地址',
  `icon` VARCHAR(500) COMMENT '图标/封面URL',
  `description` VARCHAR(255) COMMENT '描述',
  `category` VARCHAR(50) COMMENT '分类',
  `sort_order` INT DEFAULT 0 COMMENT '排序',
  `is_external` TINYINT DEFAULT 1 COMMENT '是否外站 1是 0否',
  `status` TINYINT DEFAULT 1 COMMENT '状态 1启用 0禁用',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='导航链接表';

-- SEO配置表
CREATE TABLE IF NOT EXISTS `seo_config` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `site_title` VARCHAR(200) DEFAULT '我的导航页' COMMENT '站点标题',
  `site_description` VARCHAR(500) COMMENT '站点描述',
  `site_keywords` VARCHAR(500) COMMENT '关键词',
  `allow_robots` TINYINT DEFAULT 1 COMMENT '允许爬虫 1是 0否',
  `robots_txt` TEXT COMMENT 'robots.txt内容',
  `sitemap_enabled` TINYINT DEFAULT 1 COMMENT '启用sitemap',
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='SEO配置表';

-- 站点配置表
CREATE TABLE IF NOT EXISTS `site_config` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `beian_number` VARCHAR(200) COMMENT '备案号',
  `beian_link` VARCHAR(500) COMMENT '备案跳转链接',
  `copyright_text` VARCHAR(500) DEFAULT '© 2026 我的导航页. All Rights Reserved.' COMMENT '版权信息',
  `footer_extra` TEXT COMMENT '底部额外信息（可放统计代码等）',
  `current_theme` VARCHAR(50) DEFAULT 'dark_glass' COMMENT '当前主题',
  `external_warning` TINYINT DEFAULT 1 COMMENT '外站跳转提示 1开 0关',
  `external_warning_text` VARCHAR(500) DEFAULT '您即将离开本站，跳转到第三方网站，请注意安全' COMMENT '提示文字',
  `avatar_url` VARCHAR(500) COMMENT '头像图片URL',
  `bg_image` VARCHAR(500) COMMENT '背景图片URL（留空用渐变）',
  `sub_title` VARCHAR(200) DEFAULT '简洁 · 实用 · 高效工具导航' COMMENT '副标题',
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='站点配置表';

-- 自定义主题表
CREATE TABLE IF NOT EXISTS `themes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `theme_name` VARCHAR(100) NOT NULL COMMENT '主题名称',
  `theme_key` VARCHAR(50) NOT NULL UNIQUE COMMENT '主题标识',
  `css_vars` TEXT NOT NULL COMMENT 'CSS变量JSON',
  `is_builtin` TINYINT DEFAULT 0 COMMENT '是否内置 1是 0自定义',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='主题表';

-- 管理员表
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL DEFAULT 'admin',
  `password` VARCHAR(255) NOT NULL COMMENT '密码hash',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';

-- 分类表
CREATE TABLE IF NOT EXISTS `nav_categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL COMMENT '分类名称',
  `sort_order` INT DEFAULT 0 COMMENT '排序',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='导航分类表';

-- ============================================
-- 默认数据
-- ============================================

-- 默认SEO
INSERT INTO `seo_config` (`site_title`, `site_description`, `site_keywords`, `allow_robots`, `robots_txt`, `sitemap_enabled`) VALUES
('我的个人导航', '一个简洁优雅的个人导航主页，聚合常用网站快速访问', '导航,个人主页,网址导航,书签', 1, 'User-agent: *\nAllow: /\n\nSitemap: sitemap.xml', 1);

-- 默认站点配置
INSERT INTO `site_config` (`beian_number`, `beian_link`, `copyright_text`, `footer_extra`, `current_theme`, `external_warning`, `external_warning_text`, `avatar_url`, `bg_image`, `sub_title`) VALUES
('', '', '© 2026 我的导航页. All Rights Reserved.', '', 'dark_glass', 1, '您即将离开本站，跳转到第三方网站，请注意安全', '', '', '简洁 · 实用 · 高效工具导航');

-- 默认管理员 admin / admin123
INSERT INTO `admins` (`username`, `password`) VALUES
('admin', '$2y$10$cFDpWvBKFI1FGKkar6rhfOahlCngkD/QefsEBglKsPuQbSlgRb5zu');

-- ============================================
-- 默认分类（无时间字段）
-- ============================================
INSERT INTO `nav_categories` (`id`, `name`, `sort_order`) VALUES
(1, '常用搜索', 1),
(2, '开发工具', 2),
(3, '知识学习', 3),
(4, '视频娱乐', 4),
(5, '购物生活', 5),
(6, '常用', 0);

-- ============================================
-- 默认导航数据（无时间字段）
-- ============================================
INSERT INTO `nav_links` (`id`, `title`, `url`, `icon`, `description`, `category`, `sort_order`, `is_external`, `status`) VALUES
(1, '百度', 'https://www.baidu.com', 'https://www.baidu.com/favicon.ico', '中文搜索引擎', '常用搜索', 1, 1, 1),
(3, 'GitHub', 'https://github.com', 'https://github.com/favicon.ico', '全球最大代码托管平台', '开发工具', 1, 1, 1),
(4, '哔哩哔哩', 'https://www.bilibili.com', 'https://www.bilibili.com/favicon.ico', '中国年轻世代高度聚集的文化社区', '视频娱乐', 1, 1, 1),
(5, '知乎', 'https://www.zhihu.com', 'https://www.zhihu.com/favicon.ico', '中文互联网高质量问答社区', '知识学习', 1, 1, 1),
(6, '掘金', 'https://juejin.cn', 'https://juejin.cn/favicon.ico', '面向开发者的技术社区', '开发工具', 2, 1, 1),
(7, 'MDN', 'https://developer.mozilla.org', 'https://developer.mozilla.org/favicon-48x48.png', 'Web开发权威文档', '知识学习', 2, 1, 1),
(9, '淘宝', 'https://www.taobao.com', 'https://www.taobao.com/favicon.ico', '中国最大电商平台', '购物生活', 1, 1, 1),
(10, '京东', 'https://www.jd.com', 'https://www.jd.com/favicon.ico', '正品低价京东商城', '购物生活', 2, 1, 1),
(11, '豆瓣', 'https://www.douban.com', 'https://www.douban.com/favicon.ico', '发现生活之美', '视频娱乐', 3, 1, 1),
(12, 'CSDN', 'https://www.csdn.net', 'https://www.csdn.net/favicon.ico', '专业开发者社区', '开发工具', 3, 1, 1),
(13, '必应', 'https://cn.bing.com/', '', '一个常用的搜索', '常用搜索', 1, 1, 1),
(14, '小尧blog', 'https://xy.nki.pw/', 'https://xy.nki.pw/usr/uploads/favicon.png', '小尧的个人博客，喜欢瞎折腾', '常用', 0, 1, 1);

-- ============================================
-- 内置主题 v2.0
-- ============================================

INSERT INTO `themes` (`theme_name`, `theme_key`, `css_vars`, `is_builtin`) VALUES
('暗黑毛玻璃', 'dark_glass', '{"--bg-primary":"#0a0a1a","--bg-glass":"rgba(255,255,255,0.06)","--bg-glass-hover":"rgba(255,255,255,0.12)","--text-primary":"#e8e8e8","--text-secondary":"#a0a0b0","--accent-color":"#6366f1","--accent-glow":"rgba(99,102,241,0.4)","--border-color":"rgba(255,255,255,0.1)","--card-shadow":"0 8px 32px rgba(0,0,0,0.3)","--backdrop-blur":"16px","--gradient-bg":"linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)","--card-radius":"16px","--btn-height":"62px","--btn-radius":"14px","--btn-gap":"28px","--avatar-size":"140px","--avatar-img-size":"120px","--name-size":"34px","--container-max":"560px","--bg-overlay":"rgba(0,0,0,0.45)","--glow-spread":"60px","--anim-speed":"1.2s","--btn-font-size":"16px","--line-color":"rgba(255,255,255,0.9)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#ffffff,#f0f0f0,#ffffff)"}', 1),
('星空紫', 'starry_purple', '{"--bg-primary":"#0d0015","--bg-glass":"rgba(168,85,247,0.08)","--bg-glass-hover":"rgba(168,85,247,0.16)","--text-primary":"#f0e6ff","--text-secondary":"#b8a2d8","--accent-color":"#a855f7","--accent-glow":"rgba(168,85,247,0.5)","--border-color":"rgba(168,85,247,0.25)","--card-shadow":"0 8px 32px rgba(100,0,150,0.35)","--backdrop-blur":"18px","--gradient-bg":"linear-gradient(135deg, #0d0015 0%, #1a0533 50%, #2d1b69 100%)","--card-radius":"20px","--btn-height":"62px","--btn-radius":"16px","--btn-gap":"28px","--avatar-size":"140px","--avatar-img-size":"120px","--name-size":"34px","--container-max":"560px","--bg-overlay":"rgba(13,0,21,0.5)","--glow-spread":"80px","--anim-speed":"1.2s","--btn-font-size":"16px","--line-color":"rgba(168,85,247,0.8)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#f0e6ff,#d4b8ff,#f0e6ff)"}', 1),
('极光绿', 'aurora_green', '{"--bg-primary":"#0a0f0a","--bg-glass":"rgba(16,185,129,0.07)","--bg-glass-hover":"rgba(16,185,129,0.14)","--text-primary":"#e0fff0","--text-secondary":"#90c4a8","--accent-color":"#10b981","--accent-glow":"rgba(16,185,129,0.4)","--border-color":"rgba(16,185,129,0.2)","--card-shadow":"0 8px 32px rgba(0,100,80,0.25)","--backdrop-blur":"14px","--gradient-bg":"linear-gradient(135deg, #0a0f0a 0%, #0d1f1a 50%, #134e3a 100%)","--card-radius":"14px","--btn-height":"60px","--btn-radius":"12px","--btn-gap":"24px","--avatar-size":"130px","--avatar-img-size":"110px","--name-size":"32px","--container-max":"540px","--bg-overlay":"rgba(10,15,10,0.5)","--glow-spread":"50px","--anim-speed":"1.0s","--btn-font-size":"15px","--line-color":"rgba(16,185,129,0.7)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#e0fff0,#a7f3d0,#e0fff0)"}', 1),
('日落橙', 'sunset_orange', '{"--bg-primary":"#1a0f00","--bg-glass":"rgba(249,115,22,0.08)","--bg-glass-hover":"rgba(249,115,22,0.16)","--text-primary":"#fff5e6","--text-secondary":"#d4b896","--accent-color":"#f97316","--accent-glow":"rgba(249,115,22,0.45)","--border-color":"rgba(249,115,22,0.22)","--card-shadow":"0 8px 32px rgba(150,60,0,0.3)","--backdrop-blur":"16px","--gradient-bg":"linear-gradient(135deg, #1a0f00 0%, #2d1600 50%, #4a2500 100%)","--card-radius":"18px","--btn-height":"64px","--btn-radius":"16px","--btn-gap":"28px","--avatar-size":"140px","--avatar-img-size":"120px","--name-size":"34px","--container-max":"560px","--bg-overlay":"rgba(26,15,0,0.5)","--glow-spread":"70px","--anim-speed":"1.2s","--btn-font-size":"16px","--line-color":"rgba(249,115,22,0.8)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#fff5e6,#fed7aa,#fff5e6)"}', 1),
('科技蓝', 'tech_blue', '{"--bg-primary":"#000814","--bg-glass":"rgba(59,130,246,0.07)","--bg-glass-hover":"rgba(59,130,246,0.14)","--text-primary":"#e0f0ff","--text-secondary":"#90b8d8","--accent-color":"#3b82f6","--accent-glow":"rgba(59,130,246,0.45)","--border-color":"rgba(59,130,246,0.2)","--card-shadow":"0 8px 32px rgba(0,50,150,0.3)","--backdrop-blur":"16px","--gradient-bg":"linear-gradient(135deg, #000814 0%, #001a33 50%, #003366 100%)","--card-radius":"12px","--btn-height":"58px","--btn-radius":"10px","--btn-gap":"24px","--avatar-size":"130px","--avatar-img-size":"110px","--name-size":"32px","--container-max":"560px","--bg-overlay":"rgba(0,8,20,0.5)","--glow-spread":"55px","--anim-speed":"1.0s","--btn-font-size":"15px","--line-color":"rgba(59,130,246,0.8)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#e0f0ff,#bfdbfe,#e0f0ff)"}', 1),
('粉樱', 'pink_sakura', '{"--bg-primary":"#1a0010","--bg-glass":"rgba(236,72,153,0.07)","--bg-glass-hover":"rgba(236,72,153,0.14)","--text-primary":"#ffe0f0","--text-secondary":"#d8a2c0","--accent-color":"#ec4899","--accent-glow":"rgba(236,72,153,0.4)","--border-color":"rgba(236,72,153,0.2)","--card-shadow":"0 8px 32px rgba(150,0,80,0.25)","--backdrop-blur":"16px","--gradient-bg":"linear-gradient(135deg, #1a0010 0%, #2d0518 50%, #4a0a28 100%)","--card-radius":"20px","--btn-height":"62px","--btn-radius":"18px","--btn-gap":"28px","--avatar-size":"140px","--avatar-img-size":"120px","--name-size":"34px","--container-max":"560px","--bg-overlay":"rgba(26,0,16,0.5)","--glow-spread":"65px","--anim-speed":"1.3s","--btn-font-size":"16px","--line-color":"rgba(236,72,153,0.7)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#ffe0f0,#fbcfe8,#ffe0f0)"}', 1),
('冰蓝水晶', 'ice_crystal', '{"--bg-primary":"#001a22","--bg-glass":"rgba(103,232,249,0.06)","--bg-glass-hover":"rgba(103,232,249,0.13)","--text-primary":"#e0fdfa","--text-secondary":"#7dd3c0","--accent-color":"#06b6d4","--accent-glow":"rgba(6,182,212,0.45)","--border-color":"rgba(103,232,249,0.2)","--card-shadow":"0 8px 32px rgba(0,80,100,0.3)","--backdrop-blur":"20px","--gradient-bg":"linear-gradient(135deg, #001a22 0%, #083344 50%, #164e63 100%)","--card-radius":"22px","--btn-height":"60px","--btn-radius":"16px","--btn-gap":"26px","--avatar-size":"136px","--avatar-img-size":"116px","--name-size":"33px","--container-max":"560px","--bg-overlay":"rgba(0,26,34,0.48)","--glow-spread":"75px","--anim-speed":"1.1s","--btn-font-size":"15px","--line-color":"rgba(103,232,249,0.7)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#e0fdfa,#a5f3fc,#e0fdfa)"}', 1),
('烈焰红', 'fire_red', '{"--bg-primary":"#1a0000","--bg-glass":"rgba(239,68,68,0.08)","--bg-glass-hover":"rgba(239,68,68,0.16)","--text-primary":"#ffe0e0","--text-secondary":"#d8a2a2","--accent-color":"#ef4444","--accent-glow":"rgba(239,68,68,0.45)","--border-color":"rgba(239,68,68,0.22)","--card-shadow":"0 8px 32px rgba(150,0,0,0.3)","--backdrop-blur":"16px","--gradient-bg":"linear-gradient(135deg, #1a0000 0%, #2d0505 50%, #450a0a 100%)","--card-radius":"14px","--btn-height":"64px","--btn-radius":"12px","--btn-gap":"28px","--avatar-size":"140px","--avatar-img-size":"120px","--name-size":"34px","--container-max":"560px","--bg-overlay":"rgba(26,0,0,0.5)","--glow-spread":"70px","--anim-speed":"0.9s","--btn-font-size":"16px","--line-color":"rgba(239,68,68,0.8)","--hr-height":"1px","--title-gradient":"linear-gradient(120deg,#ffe0e0,#fecaca,#ffe0e0)"}', 1);
